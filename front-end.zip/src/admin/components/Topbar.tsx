import React from "react";

const Topbar = () => {
  return (
    <nav className="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
      <span className="navbar-brand">Dashboard</span>
    </nav>
  );
};

export default Topbar;
